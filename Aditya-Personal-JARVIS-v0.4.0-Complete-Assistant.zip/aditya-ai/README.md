# Aditya Personal JARVIS v0.4.0 — Complete Assistant Starter

Android Java project for Hindi/Hinglish tap-to-talk, spoken replies, app launching, web/YouTube search, phone dialer, flashlight, text chat, and an optional secure online AI brain.

## Included Android features
- Tap-to-talk Hindi speech recognition; replies spoken by Android Text-to-Speech. Voice quality and available male-sounding voices depend on the phone's installed TTS engine.
- Addresses the user as Boss and offers a friendly check-in.
- Opens YouTube, Chrome, WhatsApp, Maps, Gmail, Camera, Android Settings.
- Searches Google and YouTube.
- Opens dialer for a phone number; user reviews and taps Call.
- Flashlight on/off.
- Text chat and unknown-question forwarding to an optional AI backend.
- AI backend URL is stored in app preferences; only HTTPS URLs are accepted. No API key is embedded in the APK.

## Connect the AI brain (required for ChatGPT-like answers)
1. Deploy `ai-backend/` on a trusted HTTPS Python host that supports Docker or Python services.
2. Set environment variable `OPENAI_API_KEY` in the host's secret/environment settings. Never put it in the Android app or a public GitHub file. Optional: set `OPENAI_MODEL` to a model available to your account.
3. Deploy the service; verify `https://YOUR-HOST/health` returns JSON. The Android app calls `https://YOUR-HOST/chat`.
4. In the app's **AI Brain Server** field, enter the full HTTPS endpoint, for example `https://YOUR-HOST/chat`, then tap **Save AI server URL**.
5. Test a normal question through the text field or voice input. Backend API usage may cost money and depends on the provider/account.

The ZIP does not include a deployed backend or an API key. Until you deploy/configure it, local commands still work but general AI answers will tell you to connect the server.

## Voice troubleshooting
- Allow microphone permission when asked.
- Ensure Google app / Speech Services is installed and updated.
- Android Settings → Text-to-speech output: select an installed engine and download Hindi voice data. The app attempts to choose a Hindi voice whose name includes `male`, but Android does not guarantee a male or human-like emotional voice.
- Speech recognition may require internet depending on the device. This app is tap-to-talk; it is not always listening for a wake word.

## YouTube actions and safety
The app can open YouTube/search results. It does **not** automatically click Like/Subscribe or publish comments; the user should choose the correct video and confirm these account actions inside YouTube. Android apps cannot safely or reliably control every other app's private UI across phone versions.

## Build via GitHub Actions
Upload the contents of this `aditya-ai` folder at the root of a GitHub repository. Keep `.github/workflows/android.yml` at repository root. Open Actions and download the `Aditya-Personal-JARVIS-APK` artifact after a successful run.

## Limitations
- No zero-error guarantee across all phones; test the generated APK on your device.
- Full online AI needs a deployed backend and a valid API key set as a server secret.
- No always-on wake word, background monitoring, or automatic likes/subscriptions/comments.
- Phone call action intentionally opens the dialer for user confirmation.

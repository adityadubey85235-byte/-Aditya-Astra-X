plugins {
    id("com.android.application")
}

android {
    namespace = "com.aditya.assistant"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.aditya.assistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "0.4.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }
    testOptions { unitTests.isIncludeAndroidResources = true }
}

dependencies {
    testImplementation("junit:junit:4.13.2")
}

package com.aditya.assistant;

import java.util.Locale;

/** Safe, offline command router. Commands are intentionally explicit and deterministic. */
public final class CommandParser {
    public enum Action { TORCH_ON, TORCH_OFF, SETTINGS, YOUTUBE, YOUTUBE_SEARCH, CHROME, WHATSAPP, MAPS, GMAIL, CAMERA, WEB_SEARCH, DIAL, GREETING, CHECK_IN, HELP, UNKNOWN }
    public static final class Result {
        public final Action action;
        public final String query;
        Result(Action action, String query) { this.action = action; this.query = query == null ? "" : query.trim(); }
    }
    private CommandParser() {}

    public static Result parse(String input) {
        String c = input == null ? "" : input.toLowerCase(Locale.ROOT).trim();
        c = c.replace("aditya jarvis", "").replace("jarvis", "").replace("aditya", "").replace("boss", "").trim();
        c = c.replaceAll("^[\\s,.:;]+", "").replaceAll("[?!.]+$", "").trim();
        if (any(c, "torch on", "flashlight on", "torch chalu", "torch jalao", "टॉर्च चालू", "flash on")) return r(Action.TORCH_ON, "");
        if (any(c, "torch off", "flashlight off", "torch band", "टॉर्च बंद", "flash off")) return r(Action.TORCH_OFF, "");
        if (any(c, "settings", "setting kholo", "सेटिंग")) return r(Action.SETTINGS, "");
        if (any(c, "chrome kholo", "open chrome", "chrome", "browser kholo", "ब्राउज़र")) return r(Action.CHROME, "");
        if (any(c, "whatsapp kholo", "open whatsapp", "whatsapp", "व्हाट्सऐप")) return r(Action.WHATSAPP, "");
        if (any(c, "google maps", "maps kholo", "open maps", "maps", "मैप")) return r(Action.MAPS, "");
        if (any(c, "gmail kholo", "open gmail", "gmail", "जीमेल")) return r(Action.GMAIL, "");
        if (any(c, "camera kholo", "open camera", "camera", "कैमरा")) return r(Action.CAMERA, "");
        if (any(c, "call ", "phone lagao", "call karo", "फोन करो", "कॉल करो")) {
            String number = strip(c, "please call", "call", "phone lagao", "call karo", "फोन करो", "कॉल करो", "ko call");
            return r(Action.DIAL, number);
        }
        if (any(c, "haal chaal", "kaise ho", "kya haal", "how are you", "mera haal", "मेरे हाल", "हाल चाल")) return r(Action.CHECK_IN, "");
        if (any(c, "hello", "namaste", "नमस्ते", "नमस्कार", "good morning", "good evening") || c.equals("hi") || c.startsWith("hi ")) return r(Action.GREETING, "");
        if (any(c, "help", "kya kar sakte", "commands", "मदद", "क्या कर सकते")) return r(Action.HELP, "");

        // Check YouTube search phrases before the generic "open YouTube" match.
        String youtubePrefix = firstPrefix(c, "youtube par ", "youtube pe ", "youtube mein ", "यूट्यूब पर ", "यूट्यूब पे ", "youtube search ", "youtube par search ", "youtube pe search ");
        if (youtubePrefix != null) {
            String q = c.substring(youtubePrefix.length()).trim();
            q = q.replaceAll("\\s+(search karo|search kar do|search|video search karo|video search|dhundo|ढूंढो|खोजो|करो)$", "").trim();
            q = q.replaceAll("^(search|video|song|gaana|गाना|वीडियो)\\s+", "").trim();
            if (!q.isEmpty()) return r(Action.YOUTUBE_SEARCH, q);
        }
        if (any(c, "youtube", "यूट्यूब")) return r(Action.YOUTUBE, "");
        String prefix = firstPrefix(c, "search for ", "search ", "google par ", "google pe ", "internet par ", "dhundo ", "ढूंढो ", "खोजो ");
        if (prefix != null) {
            String q = c.substring(prefix.length()).trim();
            q = q.replaceAll("\\s+(search karo|search kar do|search|dhundo|ढूंढो|खोजो|करो)$", "").trim();
            if (!q.isEmpty()) return r(Action.WEB_SEARCH, q);
        }
        return r(Action.UNKNOWN, "");
    }
    private static Result r(Action a, String q) { return new Result(a, q); }
    private static String firstPrefix(String text, String... prefixes) { for (String p : prefixes) if (text.startsWith(p)) return p; return null; }
    private static String strip(String text, String... prefixes) { String s = text; for (String p : prefixes) if (s.startsWith(p)) { s = s.substring(p.length()).trim(); break; } return s; }
    private static boolean any(String value, String... candidates) { for (String candidate : candidates) if (value.contains(candidate)) return true; return false; }
}

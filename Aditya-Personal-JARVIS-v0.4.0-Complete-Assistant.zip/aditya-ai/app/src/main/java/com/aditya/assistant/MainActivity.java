package com.aditya.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.text.TextUtils;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private static final int REQ_SPEECH = 101, REQ_AUDIO = 102, REQ_CAMERA = 103;
    private TextView statusText, transcriptText;
    private EditText messageInput, backendUrlInput;
    private TextToSpeech tts;
    private boolean ttsReady = false, torchOn = false, requestRunning = false;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("aditya_settings", MODE_PRIVATE);
        statusText = findViewById(R.id.statusText); transcriptText = findViewById(R.id.transcriptText);
        messageInput = findViewById(R.id.messageInput); backendUrlInput = findViewById(R.id.backendUrlInput);
        backendUrlInput.setText(prefs.getString("backend_url", ""));
        statusText.setText("Ready, Boss. Main Aditya hoon — mic dabaa kar bolo ya message likho.");
        tts = new TextToSpeech(this, this);
        findViewById(R.id.listenButton).setOnClickListener(v -> startListening());
        findViewById(R.id.sendButton).setOnClickListener(v -> {
            String msg = messageInput.getText().toString().trim();
            if (msg.isEmpty()) { speak("Boss, pehle message likh do."); return; }
            messageInput.setText("");
            ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(messageInput.getWindowToken(), 0);
            transcriptText.setText("BOSS: “" + msg + "”"); handleCommand(msg);
        });
        findViewById(R.id.saveBackendButton).setOnClickListener(v -> saveBackendUrl());
        findViewById(R.id.torchButton).setOnClickListener(v -> toggleTorch());
        findViewById(R.id.settingsButton).setOnClickListener(v -> launch(new Intent(Settings.ACTION_SETTINGS), "Settings"));
    }

    private void saveBackendUrl() {
        String url = backendUrlInput.getText().toString().trim();
        if (!url.isEmpty() && !url.startsWith("https://")) { speak("Boss, safety ke liye AI server URL HTTPS se shuru hona chahiye."); return; }
        prefs.edit().putString("backend_url", url).apply();
        speak(url.isEmpty() ? "Boss, AI server URL hata diya. Local commands phir bhi kaam karengi." : "AI server URL save ho gaya, Boss.");
    }

    @Override public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS || tts == null) { ttsReady=false; runOnUiThread(() -> statusText.setText("Voice engine nahi mila. Phone Settings mein Text-to-speech check karein.")); return; }
        int result = tts.setLanguage(new Locale("hi", "IN"));
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) result = tts.setLanguage(Locale.getDefault());
        ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED;
        if (ttsReady) {
            tts.setSpeechRate(0.94f); tts.setPitch(0.90f);
            try { Set<Voice> voices=tts.getVoices(); if (voices!=null) for (Voice voice:voices) {
                if (voice.getLocale()!=null && "hi".equals(voice.getLocale().getLanguage()) && voice.getName().toLowerCase(Locale.ROOT).contains("male")) { tts.setVoice(voice); break; }
            }} catch (Exception ignored) { }
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) { }
                @Override public void onDone(String id) { }
                @Override public void onError(String id) { runOnUiThread(() -> statusText.setText("Voice output fail hua. TTS engine/voice data check karo.")); }
            });
        } else runOnUiThread(() -> statusText.setText("Hindi voice available nahi. Settings mein Hindi TTS voice install karo."));
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO); return; }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { speak("Boss, speech recognition service nahi mili. Google app ya Speech Services update karo."); return; }
        Intent intent=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN"); intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN");
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3); intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Boss, Hindi ya Hinglish mein command bolo...");
        statusText.setText("Sun raha hoon, Boss...");
        try { startActivityForResult(intent, REQ_SPEECH); } catch (ActivityNotFoundException | SecurityException e) { speak("Boss, voice input service nahi mili. Google speech services check karo."); }
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data); if (requestCode!=REQ_SPEECH) return;
        if (resultCode==RESULT_OK && data!=null) {
            ArrayList<String> list=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (list!=null && !list.isEmpty() && list.get(0)!=null && !list.get(0).trim().isEmpty()) {
                String command=list.get(0).trim(); transcriptText.setText("BOSS SAID: “"+command+"”"); handleCommand(command);
            } else speak("Boss, awaaz samajh nahi aayi. Dobara try karo.");
        } else statusText.setText("Voice input nahi mila. Mic dobara dabao.");
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults) {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if (requestCode==REQ_AUDIO && grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED) startListening();
        else if (requestCode==REQ_AUDIO) speak("Boss, voice command ke liye microphone permission allow karo.");
        else if (requestCode==REQ_CAMERA && grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED) setTorch(!torchOn);
        else if (requestCode==REQ_CAMERA) speak("Boss, torch ke liye camera permission chahiye.");
    }

    private void handleCommand(String spoken) {
        String c=spoken.toLowerCase(Locale.ROOT).trim();
        if (containsAny(c,"like karo","video ko like","subscribe karo","channel subscribe","comment karo","comment likho","वीडियो लाइक","सब्सक्राइब करो","कमेंट करो")) {
            String q=spoken.replaceAll("(?i)(boss|aditya|jarvis|please|video ko like karo|like karo|subscribe karo|channel subscribe karo|comment karo|comment likho)", "").trim();
            openUrl("https://www.youtube.com/results?search_query="+Uri.encode(q.isEmpty()?"YouTube":q), "Boss, YouTube khol raha hoon. Video check karke Like, Subscribe ya Comment aap khud confirm karein."); return;
        }
        CommandParser.Result r=CommandParser.parse(spoken);
        switch(r.action) {
            case TORCH_ON: setTorch(true); return;
            case TORCH_OFF: setTorch(false); return;
            case SETTINGS: launch(new Intent(Settings.ACTION_SETTINGS),"Settings"); return;
            case YOUTUBE: openApp("com.google.android.youtube","YouTube"); return;
            case YOUTUBE_SEARCH:
                if (r.query.isEmpty()) { speak("Boss, YouTube par kya search karna hai?"); return; }
                openUrl("https://www.youtube.com/results?search_query="+Uri.encode(r.query),"Boss, YouTube par "+r.query+" search kar raha hoon."); return;
            case CHROME: openApp("com.android.chrome","Chrome"); return;
            case WHATSAPP: openApp("com.whatsapp","WhatsApp"); return;
            case MAPS: openApp("com.google.android.apps.maps","Google Maps"); return;
            case GMAIL: openApp("com.google.android.gm","Gmail"); return;
            case CAMERA: launch(new Intent("android.media.action.IMAGE_CAPTURE"),"Camera"); return;
            case DIAL:
                String number=r.query.replaceAll("[^0-9+*#]", "");
                if(number.isEmpty()){speak("Boss, kiska number dial karna hai?");return;}
                try{startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+Uri.encode(number))));speak("Boss, dialer khol diya. Number check karke call button dabana.");}catch(ActivityNotFoundException e){speak("Boss, phone dialer nahi mila.");} return;
            case WEB_SEARCH: if(r.query.isEmpty()){speak("Boss, kya search karna hai?");return;} openUrl("https://www.google.com/search?q="+Uri.encode(r.query),"Theek hai Boss, web search khol raha hoon."); return;
            case GREETING: speak("Namaste Boss! Main Aditya hoon. Aaj kaise ho? Sab badhiya chal raha hai?"); return;
            case CHECK_IN: speak("Boss, main yahin hoon. Aaj tumhara haal kaisa hai? Kuch pareshani hai toh batao."); return;
            case HELP: speak("Boss, main apps khol sakta hoon, Google aur YouTube search kar sakta hoon, dialer, torch aur AI chat use kar sakta hoon. AI brain ke liye server URL save karna hoga."); return;
            case UNKNOWN: default: askAiBackend(spoken); return;
        }
    }
    private boolean containsAny(String s,String... values){for(String v:values)if(s.contains(v))return true;return false;}
    private void askAiBackend(String message) {
        String endpoint=prefs.getString("backend_url","").trim();
        if(endpoint.isEmpty()){speak("Boss, is baat ka smart jawab dene ke liye AI brain server connect karna hoga. Project README mein setup diya hai. Abhi main Google search bhi khol sakta hoon."); return;}
        if(requestRunning){speak("Boss, ek jawab process ho raha hai. Thoda wait karo.");return;}
        requestRunning=true; statusText.setText("Soch raha hoon, Boss...");
        new Thread(() -> {
            HttpURLConnection conn=null;
            try {
                conn=(HttpURLConnection)new URL(endpoint).openConnection(); conn.setRequestMethod("POST"); conn.setConnectTimeout(12000); conn.setReadTimeout(25000);
                conn.setDoOutput(true); conn.setRequestProperty("Content-Type","application/json; charset=utf-8"); conn.setRequestProperty("Accept","application/json");
                JSONObject body=new JSONObject(); body.put("message",message);
                try(OutputStream os=conn.getOutputStream()){os.write(body.toString().getBytes(StandardCharsets.UTF_8));}
                int code=conn.getResponseCode(); InputStream stream=(code>=200&&code<300)?conn.getInputStream():conn.getErrorStream();
                StringBuilder text=new StringBuilder(); if(stream!=null)try(BufferedReader br=new BufferedReader(new InputStreamReader(stream,StandardCharsets.UTF_8))){String line;while((line=br.readLine())!=null)text.append(line);}
                JSONObject json=new JSONObject(text.toString()); String reply=json.optString("reply","").trim();
                if(code<200||code>=300||reply.isEmpty()) throw new Exception("Server returned "+code);
                runOnUiThread(() -> {requestRunning=false; speak(reply);});
            } catch(Exception e) {runOnUiThread(() -> {requestRunning=false; speak("Boss, AI server se connection nahi hua. URL, internet aur server logs check karo.");});}
            finally {if(conn!=null)conn.disconnect();}
        }).start();
    }
    private void openApp(String pkg,String name){Intent i=getPackageManager().getLaunchIntentForPackage(pkg);if(i!=null)launch(i,name);else speak(name+" is phone par installed nahi hai, Boss.");}
    private void launch(Intent i,String name){try{startActivity(i);speak("Ji Boss, "+name+" khol raha hoon.");}catch(ActivityNotFoundException|SecurityException e){speak("Boss, "+name+" nahi khul paaya.");}}
    private void openUrl(String url,String message){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));speak(message);}catch(ActivityNotFoundException|SecurityException e){speak("Boss, browser ya YouTube open nahi ho paaya.");}}
    private void toggleTorch(){if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.CAMERA},REQ_CAMERA);return;}setTorch(!torchOn);}
    private void setTorch(boolean on){if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.CAMERA},REQ_CAMERA);return;}try{CameraManager m=(CameraManager)getSystemService(CAMERA_SERVICE);for(String id:m.getCameraIdList()){Boolean f=m.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);if(Boolean.TRUE.equals(f)){m.setTorchMode(id,on);torchOn=on;speak(on?"Ji Boss, torch on kar di.":"Ji Boss, torch off kar di.");return;}}speak("Boss, is phone mein torch available nahi hai.");}catch(CameraAccessException|SecurityException e){speak("Boss, torch control nahi hua. Camera permission check karo.");}}
    private void speak(String msg){if(statusText!=null)statusText.setText(msg);if(tts!=null&&ttsReady){int code=tts.speak(msg,TextToSpeech.QUEUE_FLUSH,null,"reply_"+System.currentTimeMillis());if(code==TextToSpeech.ERROR&&statusText!=null)statusText.setText(msg+" (TTS error; phone voice settings check karo.)");}}
    @Override protected void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}

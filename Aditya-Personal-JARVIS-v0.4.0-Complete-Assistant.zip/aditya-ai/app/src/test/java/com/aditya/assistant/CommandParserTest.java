package com.aditya.assistant;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class CommandParserTest {
    @Test public void recognizesHindiTorchOn() { assertEquals(CommandParser.Action.TORCH_ON, CommandParser.parse("टॉर्च चालू करो").action); }
    @Test public void recognizesSettingsWithWakeName() { assertEquals(CommandParser.Action.SETTINGS, CommandParser.parse("Aditya settings kholo").action); }
    @Test public void extractsSearchQuery() { assertEquals("weather in lucknow", CommandParser.parse("search weather in Lucknow").query); }
    @Test public void recognizesYoutubeSearch() {
        CommandParser.Result result = CommandParser.parse("Aditya, YouTube par Minecraft search karo");
        assertEquals(CommandParser.Action.YOUTUBE_SEARCH, result.action);
        assertEquals("minecraft", result.query);
    }
    @Test public void recognizesDialerCommand() {
        CommandParser.Result result = CommandParser.parse("call 9876543210");
        assertEquals(CommandParser.Action.DIAL, result.action);
        assertEquals("9876543210", result.query);
    }
    @Test public void recognizesCheckIn() { assertEquals(CommandParser.Action.CHECK_IN, CommandParser.parse("mera haal chaal poochho").action); }
    @Test public void unknownCommandIsSafe() { assertEquals(CommandParser.Action.UNKNOWN, CommandParser.parse("do something magic").action); }
}

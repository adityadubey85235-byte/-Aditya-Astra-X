import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from openai import OpenAI

app = FastAPI(title="Aditya JARVIS AI Brain")
API_KEY = os.environ.get("OPENAI_API_KEY", "")
MODEL = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")
client = OpenAI(api_key=API_KEY) if API_KEY else None

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=4000)

@app.get("/health")
def health():
    return {"ok": True, "ai_configured": client is not None}

@app.post("/chat")
def chat(req: ChatRequest):
    if client is None:
        raise HTTPException(status_code=503, detail="Server owner must configure OPENAI_API_KEY")
    try:
        response = client.chat.completions.create(
            model=MODEL,
            messages=[
                {"role": "system", "content": (
                    "You are Aditya, a helpful Hindi/Hinglish personal assistant. Address the user as Boss naturally, "
                    "without overdoing it. Be warm and emotionally aware but honest that you are AI. Give useful answers, "
                    "never claim to have opened apps or performed phone actions unless the Android app did so. "
                    "Do not request passwords or secrets. For calls, purchases, posting, likes, subscriptions, or comments, "
                    "tell the user to review and confirm the final action themselves. Keep answers concise unless asked for detail."
                )},
                {"role": "user", "content": req.message}
            ],
            temperature=0.7,
            max_tokens=700
        )
        reply = (response.choices[0].message.content or "").strip()
        return {"reply": reply or "Boss, is baar jawab generate nahi hua. Dobara try karein."}
    except Exception:
        raise HTTPException(status_code=502, detail="AI provider request failed")
